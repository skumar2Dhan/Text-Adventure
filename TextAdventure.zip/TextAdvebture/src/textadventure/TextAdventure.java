
package textadventure;

import java.util.ArrayList;
import java.util.List;

public class TextAdventure 
{

	private static List<Room> rooms;
	private static List<Item> items;
	private static List<NPC> npcs;
	private static List<Exit> exits;
	private static Player player;
	private static List<String> locations;
	

	public static void main(String[] args) {
		
		int numberOfRooms=6;
		int numberOfItems=3;
		int numberOfNpcs=1;
		
		
		player=new Player();
		
                locations = new ArrayList<>();
		
		exits=new ArrayList<>();
		for(int i=0;i<8;i++)
			exits.add(new Exit());
		
		
                rooms = new ArrayList<>();
		for(int i=0;i<numberOfRooms;i++)
			rooms.add(new Room());
		
		
                items = new ArrayList<>();
		for(int i=0;i<numberOfItems;i++)
                {
			items.add(new Item());
                }
		
                npcs = new ArrayList<>();
		npcs.add(new NPC());
		
		
                rooms.get(0).setRoomNo(0);
                        
		
		
		
		
		items.get(0).setItem("sword");
		items.get(0).setRoom(1);
		items.get(1).setItem("key");
		items.get(1).setRoom(4);
		items.get(2).setItem("chest treasure");
		items.get(2).setRoom(5);
		
		
		
		npcs.get(0).setNPCName("Guard");
		npcs.get(0).setRoomno(5);
		
		
		
		locations.add("0");
		locations.add("path");
		locations.add("1");
		locations.add("2");
		locations.add("3");
		locations.add("passage");
		locations.add("4");
		locations.add("path");
		locations.add("5");
		
		
		exits.get(0).setConnection(0, 1, "path");
		exits.get(1).setConnection(0, 2, "gate");
		exits.get(2).setConnection(2, 3, "gate");
		exits.get(3).setConnection(1, 5, "passage");
		exits.get(4).setConnection(3, 5, "passage");
		exits.get(5).setConnection(2, 4, "gate");
		exits.get(6).setConnection(3, 5, "path");
		exits.get(7).setConnection(4, 5, "path");
		
                
		player.play(rooms, items, npcs,locations);
	}
	
}
