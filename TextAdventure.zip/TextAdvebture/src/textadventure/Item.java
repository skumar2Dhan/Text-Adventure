
package textadventure;

public class Item 
{

	private String ItemName;
	private int RoomNumber;
	
	
	Item(){}
	
	
	public void setItem(String itemName)
	{
		this.ItemName=itemName;
	}
	
	
	public void setRoom(int RoomNumber)
	{
		this.RoomNumber=RoomNumber;
	}
	
	
	public String getItem()
	{
		return this.ItemName;
	}
	
	
	public int getRoom()
	{
		return this.RoomNumber;
	}
	
}

