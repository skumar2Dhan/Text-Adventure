
package textadventure;

public class Room 
{
	
    private int roomNumber;
	
	
	Room()
	{
		
	}
	
	
	public void setRoomNo(int roomNumber)
	{
		this.roomNumber=roomNumber;
	}
	public int getRoomNo()
	{
		return this.roomNumber;
	}


}

