
package textadventure;

public class NPC 
{

	private String NPC_name;
	private int Room_number;
	NPC()
	{}
	
	public void setNPCName(String name)
	{
		this.NPC_name=name;
	}
	public String getNPCname()
	{
		return this.NPC_name;
	}
	public void setRoomno(int room_no)
	{
		this.Room_number=room_no;
	}
	public int getRoomno()
	{
		return this.Room_number;
	}
	
}
