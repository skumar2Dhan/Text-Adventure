
package textadventure;

public class Exit
{

	private int RoomNumberOne;
	private int RoomNumber2;
	private String ConnectionType;
	
	
	public void setConnection(int RoomNumber1,int RoomNumber2,String Type)
	{
		this.RoomNumberOne=RoomNumber1;
		this.RoomNumber2=RoomNumber2;
		this.ConnectionType=Type;
	}
}

