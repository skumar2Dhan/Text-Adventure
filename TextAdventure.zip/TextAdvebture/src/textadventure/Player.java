
package textadventure;



import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

enum Directions {
    take,
    use_sword,
    use_key,
    fight,
    trade,
    look,
    go,
    north,
    south,
    east,
    west,
}

public class Player {

    private int location;
    private List<String> itemsForInteractions;
    private int itemNumber;
  

    Player() {
        location = 1; 
        itemNumber = 0;
        
        itemsForInteractions = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            itemsForInteractions.add("");
        }
      
    }

    public void play(List<Room> rooms, List<Item> items, List<NPC> npcs, List<String> locations) {
        Scanner KeyBoard = new Scanner(System.in);

        System.out.println("Let's Start the Game! ");
        System.out.println("Here is the command list which can help you win! ;)\n");
        System.out.println("    take,(To pick up something you already found.)\n"
                + "    sword,(Found in one of the rooms and once taken can be used to kill somebody!)\n"
                + "    use_key,(Once picked, can help you get to other rooms or maybe a room with the Treasure chest! )\n"
                + "    fight,(Used to fight other player on interaction)\n"
                + "    trade,(To replace the item you already have! )\n"
                + "    look,(To look around and have a clear vision of everything around.)\n"
                + "    go,(To move forward.)\n"
                + "    north,(To look and move towards North direction )\n"
                + "    south,(To look and move towards South direction )\n"
                + "    east,(To look and move towards East direction )\n"
                + "    west,(To look and move towards West direction )\n\n" + "Note: Do include the underscores as part of the commands.\n");

        
        System.out.println("Your are on the path which is almost between room 1 and room 2");//0 and 1
        location = 1;

        while (true) {
            System.out.print("\nEnter the command from the List: ");
            String command = KeyBoard.nextLine();

            String line = null;
            Boolean validCommand = false;

            validCommand = true;

            if (validCommand) {
                if (command.equals("east") && (location < 2 || location < 5 || location < 8)) {//2 5
                    location = location + 1;
                } else if (command.equals("west") && (location > 0 || location > 3 || location > 6)) {//0 5
                    location = location - 1;
                } else if (command.equals("north") && (location > 2)) {//2
                    location = location - 3;
                } else if (command.equals("south") && (location < 6)) {//
                    location = location + 3;
                } else if (command.equals("east") || command.equals("south") || command.equals("north") || command.equals("west")) {
                    System.out.println("there is a wall there, turn around or move back from " + command + "!");
                }

                String locationInHome = locations.get(location);
                if (locationInHome.equals("0") || locationInHome.equals("1") || locationInHome.equals("2") || locationInHome.equals("3") || locationInHome.equals("4") || locationInHome.equals("5")) {
                    System.out.println("You are in room number : " + locationInHome);
                    for (int n = 0; n < 3; n++) {
                        if (items.get(n).getRoom() == Integer.parseInt(locationInHome)) {
                            System.out.println("There is a particular Item " + items.get(n).getItem() + " in room number " + locationInHome);
                            if (locationInHome.equals("5") && npcs.get(0) == null) {
                                System.out.println("You won the game, Congratulations!");
                                break;
                            }
                            if (command.equals("take")) {
                                System.out.println("You have taken the " + items.get(n).getItem() + "Item.");
                                itemsForInteractions.set(itemNumber, items.get(n).getItem());
                                itemNumber++;
                                items.get(n).setItem("");
                                
                            }
                            break;
                        }
                    }
                    if (locationInHome.equals("5") && npcs.get(0) != null) {
                        System.out.println("There is a Watcher alert in this room (Be careful!) ");
                        if (command.equals("use sword")||command.equals("use key")) {//&& items.get(2).getItem("")
                           
                                System.out.println("You have saved yourself and killed the security guard.");
                                if (command.equals("use key")) {
                          
                                    System.out.println("You opened the chest\nCongratulations! You have won the Game.");
                                    break;
                            
                            }
                        }else{
                            System.out.println("Hide behind the wall and look around, and think of a sharp item to help you get near to the chest");
                        }
                        }
                } 
                else {
                    System.out.println("You are on : " + locationInHome);
                }

            } else {
                System.out.println("Invalid Command, put some command(s) from the list provided.");
            }

        }

    }

}


